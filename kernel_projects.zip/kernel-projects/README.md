# Linux kernel driver projects

## hello
Minimal loadable kernel module. `make && sudo insmod hello.ko && sudo dmesg | tail && sudo rmmod hello`

## ringdev: ring-buffer character device (misc driver)
- `/dev/ringdev` via `misc_register`, dynamic minor
- Kernel ring buffer (module parameter `bufsize`, default 4096), mutex-protected
- `read`/`write` with blocking (wait queues) and `O_NONBLOCK` (`-EAGAIN`) behaviour
- `poll()` support (POLLIN when data, POLLOUT when space)
- `ioctl`: `RINGDEV_CLEAR`, `RINGDEV_GET_COUNT`; unknown commands return `-ENOTTY`
- Proper cleanup on unload (`misc_deregister`, `kfree`)

Build and test (Ubuntu with matching kernel headers; not WSL):
    sudo apt install build-essential linux-headers-$(uname -r)
    cd ringdev && make
    sudo insmod ringdev.ko bufsize=16
    sudo chmod 666 /dev/ringdev
    gcc -o test_ringdev test_ringdev.c && ./test_ringdev
    sudo rmmod ringdev && sudo dmesg | tail

## Test status
Built against Linux 6.12 and tested inside a User-Mode Linux kernel (`insmod`, 18 checks, `rmmod`): all passed.
Not yet run on a physical machine or a distro kernel.
