// SPDX-License-Identifier: GPL-2.0
/* ringdev: misc character device with a kernel ring buffer.
 * read/write, blocking + O_NONBLOCK, poll(), ioctl, module parameter. */
#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/mutex.h>
#include <linux/wait.h>
#include <linux/poll.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/ioctl.h>

#define RINGDEV_IOC_MAGIC 'r'
#define RINGDEV_CLEAR     _IO(RINGDEV_IOC_MAGIC, 0)
#define RINGDEV_GET_COUNT _IOR(RINGDEV_IOC_MAGIC, 1, int)

static unsigned int bufsize = 4096;
module_param(bufsize, uint, 0444);
MODULE_PARM_DESC(bufsize, "ring buffer size in bytes");

struct ringdev {
	struct miscdevice misc;
	struct mutex lock;
	wait_queue_head_t rq, wq;
	char *buf;
	unsigned int head, tail, count;
};
static struct ringdev rd;

static ssize_t ringdev_read(struct file *f, char __user *ubuf, size_t len, loff_t *off)
{
	ssize_t done = 0;

	if (mutex_lock_interruptible(&rd.lock))
		return -ERESTARTSYS;
	while (!rd.count) {
		mutex_unlock(&rd.lock);
		if (f->f_flags & O_NONBLOCK)
			return -EAGAIN;
		if (wait_event_interruptible(rd.rq, rd.count))
			return -ERESTARTSYS;
		if (mutex_lock_interruptible(&rd.lock))
			return -ERESTARTSYS;
	}
	while (len && rd.count) {
		if (put_user(rd.buf[rd.tail], ubuf + done)) {
			mutex_unlock(&rd.lock);
			return done ? done : -EFAULT;
		}
		rd.tail = (rd.tail + 1) % bufsize;
		rd.count--; len--; done++;
	}
	mutex_unlock(&rd.lock);
	wake_up_interruptible(&rd.wq);
	return done;
}

static ssize_t ringdev_write(struct file *f, const char __user *ubuf, size_t len, loff_t *off)
{
	ssize_t done = 0;

	if (mutex_lock_interruptible(&rd.lock))
		return -ERESTARTSYS;
	while (rd.count == bufsize) {
		mutex_unlock(&rd.lock);
		if (f->f_flags & O_NONBLOCK)
			return -EAGAIN;
		if (wait_event_interruptible(rd.wq, rd.count < bufsize))
			return -ERESTARTSYS;
		if (mutex_lock_interruptible(&rd.lock))
			return -ERESTARTSYS;
	}
	while (len && rd.count < bufsize) {
		char c;

		if (get_user(c, ubuf + done)) {
			mutex_unlock(&rd.lock);
			return done ? done : -EFAULT;
		}
		rd.buf[rd.head] = c;
		rd.head = (rd.head + 1) % bufsize;
		rd.count++; len--; done++;
	}
	mutex_unlock(&rd.lock);
	wake_up_interruptible(&rd.rq);
	return done;
}

static __poll_t ringdev_poll(struct file *f, poll_table *wait)
{
	__poll_t m = 0;

	poll_wait(f, &rd.rq, wait);
	poll_wait(f, &rd.wq, wait);
	mutex_lock(&rd.lock);
	if (rd.count)
		m |= EPOLLIN | EPOLLRDNORM;
	if (rd.count < bufsize)
		m |= EPOLLOUT | EPOLLWRNORM;
	mutex_unlock(&rd.lock);
	return m;
}

static long ringdev_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
	int n;

	switch (cmd) {
	case RINGDEV_CLEAR:
		mutex_lock(&rd.lock);
		rd.head = rd.tail = rd.count = 0;
		mutex_unlock(&rd.lock);
		wake_up_interruptible(&rd.wq);
		return 0;
	case RINGDEV_GET_COUNT:
		mutex_lock(&rd.lock);
		n = rd.count;
		mutex_unlock(&rd.lock);
		return put_user(n, (int __user *)arg);
	}
	return -ENOTTY;
}

static const struct file_operations fops = {
	.owner = THIS_MODULE, .read = ringdev_read, .write = ringdev_write,
	.poll = ringdev_poll, .unlocked_ioctl = ringdev_ioctl,
};

static int __init ringdev_init(void)
{
	int ret;

	if (!bufsize)
		return -EINVAL;
	rd.buf = kzalloc(bufsize, GFP_KERNEL);
	if (!rd.buf)
		return -ENOMEM;
	mutex_init(&rd.lock);
	init_waitqueue_head(&rd.rq);
	init_waitqueue_head(&rd.wq);
	rd.misc.minor = MISC_DYNAMIC_MINOR;
	rd.misc.name = "ringdev";
	rd.misc.fops = &fops;
	ret = misc_register(&rd.misc);
	if (ret) {
		kfree(rd.buf);
		return ret;
	}
	pr_info("ringdev: registered, minor %d, buffer %u bytes\n", rd.misc.minor, bufsize);
	return 0;
}

static void __exit ringdev_exit(void)
{
	misc_deregister(&rd.misc);
	kfree(rd.buf);
	pr_info("ringdev: unregistered\n");
}
module_init(ringdev_init);
module_exit(ringdev_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Manuhasa M");
MODULE_DESCRIPTION("Ring buffer character device");
