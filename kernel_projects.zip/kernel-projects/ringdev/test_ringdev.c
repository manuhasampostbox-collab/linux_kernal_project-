/* Userspace test for /dev/ringdev. Run: sudo insmod ringdev.ko bufsize=16 ; sudo ./test_ringdev */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <poll.h>
#include <sys/ioctl.h>
#define RINGDEV_CLEAR     _IO('r', 0)
#define RINGDEV_GET_COUNT _IOR('r', 1, int)
static int fails;
#define CHECK(name, cond) do { int ok = (cond); printf("%s %s\n", ok ? "PASS" : "FAIL", name); if (!ok) fails++; } while (0)
int main(void)
{
	char rb[32] = {0}; int cnt = -1;
	int fd = open("/dev/ringdev", O_RDWR | O_NONBLOCK);
	if (fd < 0) { perror("open /dev/ringdev"); return 2; }
	ioctl(fd, RINGDEV_CLEAR);
	CHECK("write 10", write(fd, "hello ring", 10) == 10);
	CHECK("GET_COUNT==10", ioctl(fd, RINGDEV_GET_COUNT, &cnt) == 0 && cnt == 10);
	CHECK("read 10", read(fd, rb, 32) == 10 && !memcmp(rb, "hello ring", 10));
	CHECK("empty read EAGAIN", read(fd, rb, 1) < 0 && errno == EAGAIN);
	CHECK("write 19 into 16-byte ring", write(fd, "0123456789ABCDEFXYZ", 19) == 16);
	CHECK("full write EAGAIN", write(fd, "Z", 1) < 0 && errno == EAGAIN);
	struct pollfd p = { fd, POLLIN | POLLOUT, 0 };
	CHECK("poll full: POLLIN only", poll(&p, 1, 0) == 1 && (p.revents & POLLIN) && !(p.revents & POLLOUT));
	CHECK("partial read 5", read(fd, rb, 5) == 5 && rb[0] == '0');
	CHECK("wrap write 5", write(fd, "abcde", 5) == 5);
	memset(rb, 0, sizeof rb);
	CHECK("wrap read 16 in order", read(fd, rb, 32) == 16 && !memcmp(rb, "56789ABCDEFabcde", 16));
	CHECK("CLEAR", ioctl(fd, RINGDEV_CLEAR) == 0);
	CHECK("unknown ioctl ENOTTY", ioctl(fd, _IO('r', 9)) < 0 && errno == ENOTTY);
	close(fd);
	puts(fails ? "RESULT: FAILED" : "RESULT: ALL PASSED");
	return fails != 0;
}
